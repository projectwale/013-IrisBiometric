# import required libraries
import cv2
import os

# read input image
img = cv2.imread('1.jpeg')

# convert to grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# read the haarcascade to detect the faces in an image
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

# read the haarcascade to detect the eyes in an image
eye_cascade = cv2.CascadeClassifier('haarcascade_eye_tree_eyeglasses.xml')

# detects faces in the input image
faces = face_cascade.detectMultiScale(gray, 1.3, 4)

# create a directory to save the cropped eye images
if not os.path.exists('eye_crops'):
    os.makedirs('eye_crops')

# loop over the detected faces
for i, (x, y, w, h) in enumerate(faces):
    roi_gray = gray[y:y+h, x:x+w]
    roi_color = img[y:y+h, x:x+w]

    # detects eyes within the detected face area (roi)
    eyes = eye_cascade.detectMultiScale(roi_gray)

    # loop over the detected eyes
    for j, (ex, ey, ew, eh) in enumerate(eyes):
        # crop the eye region
        eye_crop = roi_color[ey:ey+eh, ex:ex+ew]

        # save the cropped eye image
        eye_filename = f'eye_crops/face_{i}_eye_{j}.jpg'
        cv2.imwrite(eye_filename, eye_crop)

        # draw a rectangle around the eye in the original image
        cv2.rectangle(roi_color, (ex, ey), (ex+ew, ey+eh), (0, 255, 255), 2)

# display the image with detected eyes and save the result
cv2.imshow('Eyes Detection', img)
cv2.waitKey(0)
cv2.destroyAllWindows()
