from flask import Flask,render_template,request,session
from werkzeug.utils import secure_filename
import numpy as np
from mtcnn.mtcnn import MTCNN
import tensorflow
import cv2
from tensorflow.keras.preprocessing import image
import os

from matplotlib import pyplot as plt

detector = MTCNN()

json_file = open('allmodel/res_model.json', 'r')
loaded_model_json = json_file.read()
loaded_model = tensorflow.keras.models.model_from_json(loaded_model_json)
loaded_model.load_weights("allmodel/res_model.h5")

segmentmodel = tensorflow.keras.models.load_model('allmodel/Iria_90.h5', compile=False)
print("Loaded model from disk")

app = Flask(__name__)
app.secret_key = 'any random string'
    
@app.route("/",methods=['POST','GET'])
def index():    
    return render_template('index.html')

@app.route('/check')
def check():
    return render_template('check_biometric.html') 

class_name = ("Gray", "Blue Gray", "Brown", "Brown Gray", "Brown Black", "Green", "Blue Gray", "Other")
EyeColor = {
    class_name[0] : ((166, 21, 50), (240, 100, 85)),
    class_name[1] : ((166, 2, 25), (300, 20, 75)),
    class_name[2] : ((2, 20, 20), (40, 100, 60)),
    class_name[3] : ((20, 3, 30), (65, 60, 60)),
    class_name[4] : ((0, 10, 5), (40, 40, 25)),
    class_name[5] : ((60, 21, 50), (165, 100, 85)),
    class_name[6] : ((60, 2, 25), (165, 20, 65))
}

def check_color(hsv, color):
    if (hsv[0] >= color[0][0]) and (hsv[0] <= color[1][0]) and (hsv[1] >= color[0][1]) and \
    hsv[1] <= color[1][1] and (hsv[2] >= color[0][2]) and (hsv[2] <= color[1][2]):
        return True
    else:
        return False

def find_class(hsv):
    color_id = 7
    for i in range(len(class_name)-1):
        if check_color(hsv, EyeColor[class_name[i]]) == True:
            color_id = i

    return color_id

def eye_color(image):
    imgHSV = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    h, w = image.shape[0:2]
    imgMask = np.zeros((image.shape[0], image.shape[1], 1))
    
    result = detector.detect_faces(image)
    print(result)
    if result == []:
        print('Warning: Can not detect any face in the input image!')
        return

    bounding_box = result[0]['box']
    left_eye = result[0]['keypoints']['left_eye']
    right_eye = result[0]['keypoints']['right_eye']

    eye_distance = np.linalg.norm(np.array(left_eye)-np.array(right_eye))
    eye_radius = eye_distance/15 # approximate
   
    cv2.circle(imgMask, left_eye, int(eye_radius), (255,255,255), -1)
    cv2.circle(imgMask, right_eye, int(eye_radius), (255,255,255), -1)

    cv2.rectangle(image,
              (bounding_box[0], bounding_box[1]),
              (bounding_box[0]+bounding_box[2], bounding_box[1] + bounding_box[3]),
              (255,155,255),
              2)

    cv2.circle(image, left_eye, int(eye_radius), (0, 155, 255), 1)
    cv2.circle(image, right_eye, int(eye_radius), (0, 155, 255), 1)

    eye_class = np.zeros(len(class_name), np.float)

    for y in range(0, h):
        for x in range(0, w):
            if imgMask[y, x] != 0:
                eye_class[find_class(imgHSV[y,x])] +=1 

    main_color_index = np.argmax(eye_class[:len(eye_class)-1])

    print("\nDominant Eye Color: ", class_name[main_color_index])
    
    label = '%s' % class_name[main_color_index]  
    cv2.putText(image, label, (left_eye[0]-10, left_eye[1]-40), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (155,255,0))
    output_path = 'static/output/output_image.jpg'
    cv2.imwrite(output_path, image)
    return str(class_name[main_color_index])

def displaypopup(prediction_image):        
    cv2.namedWindow('Segmented Mask', cv2.WINDOW_NORMAL)
    cv2.moveWindow('Segmented Mask', 500, 500)
    cv2.imshow('Segmented Mask', prediction_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
def getValidation(filename_secure):
    best_frame = cv2.imread('static/image.'+filename_secure.split('.')[1])
    if best_frame is not None:
          
        gray = cv2.cvtColor(best_frame, cv2.COLOR_BGR2GRAY)
        face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
        eye_cascade = cv2.CascadeClassifier('haarcascade_eye_tree_eyeglasses.xml')
        
        faces = face_cascade.detectMultiScale(gray, 1.3, 4)
        print("is faces available")
        print(list(faces))
        
        testinglst=[]
        if len(list(faces)) > 0:
        
            for i, (x, y, w, h) in enumerate(faces):
                roi_color = best_frame[y:y+h, x:x+w]
                eyes = eye_cascade.detectMultiScale(roi_color)
                
                eyecolor = eye_color(roi_color)

                # cv2.imwrite('result.jpg', best_frame)  
                
                for j, (ex, ey, ew, eh) in enumerate(eyes):
                    eye_crop = roi_color[ey:ey+eh, ex:ex+ew]
                    resized_eye = cv2.resize(eye_crop, (128, 128))
                    
                    if j == 0:
                        eye_filename = 'eye_left.jpg'
                        cv2.imwrite('eye_left1.jpg', resized_eye)
                        cv2.imwrite(eye_filename, resized_eye)
                        testinglst.append('eye_left.jpg')
                    else:
                        eye_filename = 'eye_right.jpg'
                        cv2.imwrite(eye_filename, resized_eye)
                        testinglst.append('eye_right.jpg')
            
            finalName='None'
            for i in testinglst:
                print(i)
                image_size=224
                path=i
                img = image.load_img(path, target_size=(image_size, image_size))
                x = image.img_to_array(img)
                img_4d=x.reshape(1,224,224,3)
                model = loaded_model
                predictions = model.predict(img_4d)
                print(predictions[0])
                new_pred=np.argmax(predictions[0])
                print(new_pred)
            
                dict1={0:'Yash',
                        1:'Roshan'}
            
                a=dict1[new_pred]
                
                if finalName == 'None' or finalName == str(a):
                    finalName = str(a)
                else:
                    finalName = "None"
                    
            
                print(str(a))
                print("-----------------------------------------------")
                        
            SIZE_X = 128
            SIZE_Y = 128
            OGX = 3000
            OGY = 1700
            
            imageofgr = cv2.imread('eye_left1.jpg', cv2.IMREAD_GRAYSCALE)
            cv2.imwrite('eye_left1.jpg', imageofgr)
            
            test_img = cv2.imread('eye_left1.jpg', cv2.IMREAD_COLOR)
            test_img = cv2.cvtColor(test_img, cv2.COLOR_RGB2BGR)
            test_image = test_img
            test_img = cv2.resize(test_img, (SIZE_Y, SIZE_X))    
            
            test_img = np.expand_dims(test_img, axis=0)
            
            prediction = segmentmodel.predict(test_img)
            
            test_image = cv2.resize(test_image, (OGX, OGY))
            prediction_image = prediction.reshape((SIZE_X,SIZE_Y))
            
            prediction_image = cv2.resize(prediction_image, (OGX, OGY))
            plt.imsave('static/output/segmented.jpg', prediction_image, cmap='gray')
            
            imgg = cv2.imread('static/output/segmented.jpg')
            
            imgg = cv2.resize(imgg, (OGX, OGY))
            imgg = cv2.cvtColor(imgg, cv2.COLOR_RGB2BGR)
            annd = cv2.bitwise_and(imgg, test_image)
            
            plt.imsave('static/output/segmentedfinal.jpg', annd, cmap='gray')
            
            os.remove('eye_left.jpg')
            os.remove('eye_right.jpg')
            os.remove('eye_left1.jpg')
    
            return str(finalName)+"|"+eyecolor
        else:
            return "fail"
       
@app.route('/validateIris',methods=['POST','GET'])
def validateIris():
    if request.method == "POST":
        
        image1= request.files['image'] 
        
        filename_secure = secure_filename(image1.filename)
        image1.save('static/image.'+filename_secure.split('.')[1])
        
        status = getValidation(filename_secure)
        print("---------------------------")
        print(status)
        print("---------------------------")
        session['userinfo'] = status
        if status.startswith("None"):
            return "fail"
        else:
            return status
    
    return render_template('check_biometric.html')

@app.route('/startCamera',methods=['POST','GET'])
def startCamera():
    if request.method == "POST":
        
        status= request.form['status'] 
        print(status)
        
        video_capture = cv2.VideoCapture(0)
        video_capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)  # Set the frame width
        video_capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 960)  # Set the frame height
        video_capture.set(cv2.CAP_PROP_FPS, 7)  # Set the frame rate

        if not video_capture.isOpened():
            print("Error: Could not open camera")
            exit()

        fps = int(video_capture.get(cv2.CAP_PROP_FPS))
        duration = 3  # in seconds
        frame_count = fps * duration
        frame_number = 0

        best_frame = None
        best_frame_quality = -1

        for i in range(frame_count):
            ret, frame = video_capture.read()
            if not ret:
                break
            
            output = cv2.resize(frame, (600, 600))
            cv2.imshow('Camera Feed', output)
            
            frame_quality = frame.mean()
            
            result = detector.detect_faces(frame)
            
            if frame_quality > best_frame_quality and result != []:
                print('IN')
                print(result)
                best_frame = frame.copy()
                best_frame_quality = frame_quality
                break
            
            frame_number += 1
            
            key = cv2.waitKey(1)
            if key == ord('q'):
                break
            
        # Release the camera capture object
        video_capture.release()
        cv2.destroyAllWindows()
        
        cv2.imwrite('static/image.jpg', best_frame)        
        status = getValidation('static/image.jpg')
        
        print("---------------------------")
        print(status)
        print("---------------------------")
        session['userinfo'] = status
        if status.startswith("None"):
            return "fail"
        else:
            return status
    
    return render_template('check_biometric.html')

@app.route('/result')
def result():
    userinfo = session.get("userinfo")  
    data = userinfo.split("|")
    
    return render_template('output.html',user=data[0],color=data[1]) 

@app.route('/aboutus')
def aboutus():
    return render_template('aboutus.html') 

if __name__ == '__main__':
    app.run('0.0.0.0')
    # app.run(debug=True)