import cv2
import numpy as np
from mtcnn.mtcnn import MTCNN
import tensorflow
from tensorflow.keras.preprocessing import image

import cv2
from matplotlib import pyplot as plt
from PIL import Image

detector = MTCNN()

json_file = open('allmodel/vgg_model.json', 'r')
loaded_model_json = json_file.read()
loaded_model = tensorflow.keras.models.model_from_json(loaded_model_json)
loaded_model.load_weights("allmodel/vgg_model.h5")
print("Loaded model from disk")

# ----------------------------------------------------------------------------------------------------------------

def resize(img, percent):
    print('image.shape : {}'.format(img.shape))
    width = int(img.shape[1] * percent / 100)
    height = int(img.shape[0] * percent / 100)
    dim = (width, height)
    # resize image
    resized = cv2.resize(img, dim, interpolation = cv2.INTER_AREA)
    strongest_i,strongest_j = np.where(resized >= 200) 
    resized[strongest_i, strongest_j] = 0
    
    print("resized.shape : {}".format(resized.shape))
    return resized

def my_convolve(img, filter):
    rows, cols = img.shape
    convolved_img = np.zeros((rows - filter.shape[0] + 1, cols - filter.shape[1] + 1))
    for row in range(convolved_img.shape[0]):
        for col in range(convolved_img.shape[1]):
            convolved_img[row, col] = np.sum(np.multiply(img[row:row+filter.shape[0], col:col + filter.shape[1]], filter))

    return convolved_img

def sobel_filters(img):
  edge_threshold = 7
  Hx = np.array([[1, 0, -1], [edge_threshold, 0, -edge_threshold], [1, 0, -1]])
  Hy = np.array([[1, edge_threshold, 1], [0, 0, 0], [-1, -edge_threshold, -1]])

  Gx = my_convolve(img, Hx)
  Gy = my_convolve(img, Hy)
  G = np.sqrt(np.power(Gx, 2) + np.power(Gy, 2))

  strongest_i,strongest_j = np.where(G >= 200) 
  G[strongest_i, strongest_j] = 0

  theta = np.arctan2(Gy, Gx)
  return (G, theta)

def non_max_suppression(img, D):
    rows = img.shape[0]
    cols = img.shape[1]
    non_max = np.zeros((rows,cols), dtype=np.int32)
    angle = D * 180. / np.pi
    for i in range(2, rows - 2):
        for j in range(2, cols - 2):
            try:
                q = []
                if ((angle[i,j] < 22.5) and (-22.5 <= angle[i,j])) or ((angle[i,j] < -157.5) and (157.5 <= angle[i,j]))  :  # horizental
                    q = [img[i, j+1], img[i, j+2] , img[i-1, j+2], img[i+1, j+2], img[i, j-1], img[i, j-2] , img[i-1, j-2], img[i+1, j-2]]
                elif ((angle[i,j] < 67.5) and (22.5 <= angle[i,j])) or ((angle[i,j] < -112.5) and (-157.5 <= angle[i,j]))  :  # 45degree
                    q = [img[i - 1, j + 1], img[i - 1 , j+2] , img[i-2, j+1], img[i-2, j+2], img[i+1, j-1], img[i+1, j-2] , img[i+2, j-1], img[i+2, j-2]]
                elif ((angle[i,j] < 112.5) and (67.5 <= angle[i,j])) or ((angle[i,j] < -67.5) and (-112.5 <= angle[i,j]))  :  # vertical
                    q = [img[i - 1, j], img[i - 2, j] , img[i-2, j+1], img[i-2, j-1], img[i+1, j], img[i+2, j] , img[i+2, j+1], img[i+2, j-1]]
                else: # 135degree
                    q = [img[i + 1, j + 1], img[i + 1 , j+2] , img[i+2, j+1], img[i+2, j+2], img[i-1, j-1], img[i-1, j-2] , img[i-2, j-1], img[i-2, j-2]]
                q.sort()
                if (img[i,j] >= q[-3]):
                    non_max[i,j] = img[i,j]
                else:
                    non_max[i,j] = 0
            except IndexError as e:
                print(e)
                pass
    return non_max

def threshold_img(img):
    highThreshold = img.max() * 0.1
    img = img.astype('uint8')
    
    otsu_threshold_val, ret_matrix = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    lowThreshold = otsu_threshold_val
    rows, cols = img.shape
    res = np.zeros((rows, cols), dtype=np.int32)

    strong = np.int32(255)

    strongest_i,strongest_j = np.where(img == 255) 
    strong_i, strong_j = np.where(img >= highThreshold)
    zeros_i, zeros_j = np.where((img < lowThreshold)  )
    mid_i, mid_j = np.where((img <= highThreshold) & (img >= lowThreshold))
    res[strong_i, strong_j] = strong
    res[ mid_i, mid_j] = 0
    res[ zeros_i, zeros_j] = 0
    res[strongest_i, strongest_j] = 0
    return (res)

def hysteresis(img):
    rows, cols = img.shape

    pixel_threshold = 2
    
    weak = np.int32(75)
    strong = np.int32(255)

    for i in range(1, rows - pixel_threshold -1):
        for j in range(1, cols - pixel_threshold - 1):
            if (img[i,j] == weak):
                for k in range(-pixel_threshold, pixel_threshold+1):
                    for q in range(-pixel_threshold, pixel_threshold+1):
                        if img[i+k, j+q] == strong:
                            img[i, j] = strong
                        else:
                            img[i, j] = 0
    return img

def calc_cos_sin(angles, r_range=[30, 100]):
    _sin = np.sin(angles * np.pi / 180 )
    _cos = np.cos(angles * np.pi / 180 )
    # plt.plot(_sin)
    # plt.plot(_cos)
    # plt.show()
    sin_out = []
    cos_out = []
    r_out = []

    for r in range(r_range[0], r_range[1]):
        for angle in angles:
            sin_out.append((r * _sin[angle]))
            cos_out.append((r * _cos[angle]))
            r_out.append(r)
    return np.array(sin_out), np.array(cos_out), np.array(r_out)

def x_y_calc(x, y, _sin, _cos, _r, x_range, y_range):
    # print(x_range, y_range)
    a = np.round(x - _cos)# x - r * cos(theta)
    b = np.round(y - _sin)# y - r * sin(theta)

    a_b = np.stack((a, b, _r), axis=-1) # a_b = [a, b, r]
    a_b = a_b[np.logical_and(np.logical_and(a_b[:,0] > x_range[0], a_b[:,0] < x_range[1]) ,np.logical_and(a_b[:,1] > y_range[0], a_b[:,1] < y_range[1]))] #filter a_b

    _a = a_b[:,0].flatten().astype('int32')
    _b = a_b[:,1].flatten().astype('int32')
    _r = a_b[:,2].flatten().astype('int32')

    np.add.at(accumulator, (_a, _b, _r), 1)
    return 0

x_y_func = np.vectorize(x_y_calc, signature='(),(),(k),(k),(k),(m),(m)->()', otypes=[np.int32])

def hough(input, threshold, r_range, x_range = [], y_range = []):

    print(input.shape)
    edges = np.where(input > 0)

    global accumulator
    accumulator = np.zeros((input.shape[0], input.shape[1], r_range[1]))
    print(edges[0].shape[0], "   ", edges[1].shape[0])

    _sin, _cos, _r = calc_cos_sin(np.arange(0, 361), r_range)

    if x_range == [] : x_range = [0, input.shape[0]]
    if y_range == [] : y_range = [0, input.shape[1]]

    _acc = x_y_func(edges[0], edges[1], _sin, _cos, _r, x_range, y_range)
    
    result = np.where(accumulator > threshold) #check threshold
    results = np.stack((result[0], result[1], result[2], accumulator[result]), axis=-1) #results = [a, b, r, vote]
    results = sorted(results, key=lambda x: -x[-1]) #sort according to votes
    return results

def last_filter(circles): 
    b, a, r, v = circles[0]
    for d, c, g, e in circles:
        if  np.abs(c + g) - np.abs(a + r) > 5 and np.abs(a - r) - np.abs(c - g) > 5 and np.abs(d + g) - np.abs(b + r) > 5 and np.abs(b - r) - np.abs(d - g) > 5 and np.abs(a - c) < 10 and np.abs(b - d) < 10 and np.abs(r - g) > 25 :
            return [(b, a, r, v)  ,(d, c, g, e)]
    for d, c, g, e in circles:
        if  np.abs(c + g) - np.abs(a + r) > 5 and np.abs(a - r) - np.abs(c - g) > 5 and np.abs(d + g) - np.abs(b + r) > 5 and np.abs(b - r) - np.abs(d - g) > 5  and np.abs(r - g) > 50 :
            return [(b, a, r, v)  ,(d, c, g, e)]

def draw_mask(circles, image):
    image_copy = image.copy()
    # Print the output
    (x , y, r, v) = circles[0]
    (x1 , y1, r1, v1) = circles[1]

    cv2.circle(image_copy, (int(y) , int(x)), int(r), (255,0,0), 2)
    cv2.circle(image_copy, (int(y) , int(x)), int(r1), (255,0,0), 2)

    gray_copy = gray.copy()
    cv2.circle(gray_copy, (int(y) * 5 , int(x) * 5), int(r) * 5, (255,0,0), 2)
    cv2.circle(gray_copy, (int(y) *5 , int(x) * 5  ), int(r1) * 5, (255,0,0), 2)

    gray_copy1 = img.copy()
    # draw masks
    mask1 = np.zeros_like(gray_copy1)
    mask1 = cv2.circle(mask1, (int(circles[0][1] * 5), int(circles[0][0])* 5), int(circles[0][2])* 5, (255,255,255), -1)
    mask2 = np.zeros_like(gray_copy1)
    mask2 = cv2.circle(mask2, (int(circles[0][1]* 5), int(circles[0][0])* 5), int(circles[1][2])* 5, (255,255,255), -1)
    mask = cv2.subtract(mask2, mask1)
    masked_resized = cv2.bitwise_and(gray_copy1,mask)
    return masked_resized, gray_copy

def daugman_normalizaiton(image, height, width, r_in, r_out, a, b):    

    thetas = np.arange(0, 2 * np.pi, 2 * np.pi / width)  # width values (thetas)

    img = np.zeros((height,width, 3), np.uint8)

    for (i, theta) in enumerate(thetas):
        for j in range(height):
            for channel in range(2):
                r = j / height

                Xin = a + r_in * np.cos(theta)
                Yin = b + r_in * np.sin(theta)
                Xo = a + r_out * np.cos(theta)
                Yo = b + r_out * np.sin(theta)

                Xc = (1 - r) * Xin + r * Xo
                Yc = (1 - r) * Yin + r * Yo

                color = image[int(Xc)][int(Yc)][int(channel)]
                img[j][i][int(channel)] = color
    return img  


# ----------------------------------------------------------------------------------------------------------------
# define HSV color ranges for eyes colors
class_name = ("Gray", "Blue Gray", "Brown", "Brown Gray", "Brown Black", "Green", "Blue Gray", "Other")
# class_name = ("Blue", "Blue Gray", "Brown", "Brown Gray", "Brown Black", "Green", "Green Gray", "Other")
EyeColor = {
    class_name[0] : ((166, 21, 50), (240, 100, 85)),
    class_name[1] : ((166, 2, 25), (300, 20, 75)),
    class_name[2] : ((2, 20, 20), (40, 100, 60)),
    class_name[3] : ((20, 3, 30), (65, 60, 60)),
    class_name[4] : ((0, 10, 5), (40, 40, 25)),
    class_name[5] : ((60, 21, 50), (165, 100, 85)),
    class_name[6] : ((60, 2, 25), (165, 20, 65))
}

def check_color(hsv, color):
    if (hsv[0] >= color[0][0]) and (hsv[0] <= color[1][0]) and (hsv[1] >= color[0][1]) and \
    hsv[1] <= color[1][1] and (hsv[2] >= color[0][2]) and (hsv[2] <= color[1][2]):
        return True
    else:
        return False

# define eye color category rules in HSV space
def find_class(hsv):
    color_id = 7
    for i in range(len(class_name)-1):
        if check_color(hsv, EyeColor[class_name[i]]) == True:
            color_id = i

    return color_id

def eye_color(image):
    cv2.imshow('EYE', image)
    imgHSV = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    h, w = image.shape[0:2]
    imgMask = np.zeros((image.shape[0], image.shape[1], 1))
    
    result = detector.detect_faces(image)
    print(result)
    if result == []:
        print('Warning: Can not detect any face in the input image!')
        return

    bounding_box = result[0]['box']
    left_eye = result[0]['keypoints']['left_eye']
    right_eye = result[0]['keypoints']['right_eye']

    eye_distance = np.linalg.norm(np.array(left_eye)-np.array(right_eye))
    eye_radius = eye_distance/15 # approximate
   
    cv2.circle(imgMask, left_eye, int(eye_radius), (255,255,255), -1)
    cv2.circle(imgMask, right_eye, int(eye_radius), (255,255,255), -1)

    cv2.rectangle(image,
              (bounding_box[0], bounding_box[1]),
              (bounding_box[0]+bounding_box[2], bounding_box[1] + bounding_box[3]),
              (255,155,255),
              2)

    cv2.circle(image, left_eye, int(eye_radius), (0, 155, 255), 1)
    cv2.circle(image, right_eye, int(eye_radius), (0, 155, 255), 1)

    eye_class = np.zeros(len(class_name), np.float)

    for y in range(0, h):
        for x in range(0, w):
            if imgMask[y, x] != 0:
                eye_class[find_class(imgHSV[y,x])] +=1 

    main_color_index = np.argmax(eye_class[:len(eye_class)-1])
    total_vote = eye_class.sum()

    print("\n\nDominant Eye Color: ", class_name[main_color_index])
    print("\n **Eyes Color Percentage **")
    for i in range(len(class_name)):
        print(class_name[i], ": ", round(eye_class[i]/total_vote*100, 2), "%")
    
    label = '%s' % class_name[main_color_index]  
    cv2.putText(image, label, (left_eye[0]-10, left_eye[1]-40), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (155,255,0))
    cv2.imshow('EYE-COLOR-DETECTION', image)

# ----------------------------------------------------------------------------------------------------------------

# Initialize the camera capture
video_capture = cv2.VideoCapture(0)
video_capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)  # Set the frame width
video_capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 960)  # Set the frame height
video_capture.set(cv2.CAP_PROP_FPS, 7)  # Set the frame rate


# Check if the camera is opened successfully
if not video_capture.isOpened():
    print("Error: Could not open camera")
    exit()

# Set the frame rate (fps) and duration for capturing
fps = int(video_capture.get(cv2.CAP_PROP_FPS))
duration = 3  # in seconds
frame_count = fps * duration

# Iterate through the frames to find the best clear frame
best_frame = None
best_frame_quality = -1

for i in range(frame_count):
    ret, frame = video_capture.read()
    if not ret:
        break
    
    # For simplicity, let's calculate the mean pixel intensity as a basic quality metric
    frame_quality = frame.mean()
    # print(frame_quality)
    
    result = detector.detect_faces(frame)
    
    # Update the best frame if the current frame is clearer
    if frame_quality > best_frame_quality and result != []:
        print('IN')
        print(result)
        best_frame = frame.copy()
        best_frame_quality = frame_quality

# Save the best frame as an image
if best_frame is not None:
    
    # convert to grayscale
    gray = cv2.cvtColor(best_frame, cv2.COLOR_BGR2GRAY)

    # read the haarcascade to detect the faces in an image
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

    # read the haarcascade to detect the eyes in an image
    eye_cascade = cv2.CascadeClassifier('haarcascade_eye_tree_eyeglasses.xml')

    # detects faces in the input image
    faces = face_cascade.detectMultiScale(gray, 1.3, 4)   
        
    # cv2.imwrite('eye_crops/best_frame.jpg', best_frame)
    # print("Best frame saved as 'best_frame.jpg'")

    # Loop over the detected faces
    for i, (x, y, w, h) in enumerate(faces):
        roi_gray = gray[y:y+h, x:x+w]
        margin = 25
        roi_color1 = best_frame[y-margin:y+h+margin, x-margin:x+w+margin]
        roi_color = best_frame[y:y+h, x:x+w]
    
        # Resize the face image to 512x512
        resized_face = cv2.resize(roi_color1, (384, 384))
    
        # Save the sharpened face image
        face_filename = 'face.jpg'
        cv2.imwrite(face_filename, roi_color1)
        print("Best frame saved as 'face.jpg'")
    
        # Detect eyes within the detected face area (roi)
        eyes = eye_cascade.detectMultiScale(roi_color)
    
        # Loop over the detected eyes
        for j, (ex, ey, ew, eh) in enumerate(eyes):
            # Crop the eye region
            eye_crop = roi_gray[ey:ey+eh, ex:ex+ew]
    
            # Resize the eye image to 640x480
            resized_eye = cv2.resize(eye_crop, (256, 256))
    
            if j == 0:
                # Save the sharpened eye image
                eye_filename = 'eye_left.jpg'
                cv2.imwrite(eye_filename, resized_eye)
            else:                
                # Save the sharpened eye image
                eye_filename = 'eye_right.jpg'
                cv2.imwrite(eye_filename, resized_eye)
                

    image1 = Image.open('eye_right.jpg')
                
    sunset_resized = image1.resize((768, 576))
    sunset_resized.save('new.png')
    
    image_path ='new.png'
    image1 = cv2.imread(image_path)
    img = cv2.cvtColor(image1, cv2.COLOR_BGR2RGB)
    gray =  cv2.cvtColor(image1, cv2.COLOR_RGB2GRAY)
    
    resized = resize(gray, 20)
    blur = (1 / 16.0) * np.array([[1., 2., 1.],
                                     [2., 4., 2.],
                                     [1., 2., 1.]])
    
    blurred = my_convolve(resized, blur)
    sobel = sobel_filters(blurred)
    non_max = non_max_suppression(sobel[0], sobel[1])
    threshold = threshold_img(non_max)
    edges = hysteresis(threshold)
    circles = hough(non_max, 50, r_range=[10, 60], x_range=[40, 70], y_range=[60, 90])  
    filtered_circles = last_filter(circles)
    
    masked_resized, image_circles = draw_mask(filtered_circles, resized)
    image_nor = daugman_normalizaiton(masked_resized,90,360, filtered_circles[0][2] * 5, filtered_circles[1][2] * 5, filtered_circles[0][0] * 5, filtered_circles[0][1] * 5)
           
    # Draw Outputs
    fig, ax = plt.subplots(figsize=(30, 10))
    ax.axis('off')
    ax6 = fig.add_subplot(231)
    ax6.imshow(image1)
    ax6.set_title("image")
    ax5= fig.add_subplot(232)
    ax5.imshow(gray , cmap='gray', vmin=0, vmax=255)
    ax5.set_title("gray_image")
    ax1= fig.add_subplot(233)
    ax1.imshow(edges , cmap='gray', vmin=0, vmax=255)
    ax1.set_title("edged_image")
    ax2= fig.add_subplot(234)
    ax2.imshow(image_circles, cmap='gray', vmin=0, vmax=255)
    ax2.set_title("circles ")
    ax3= fig.add_subplot(235)
    ax3.imshow(masked_resized, cmap='gray', vmin=0, vmax=255)
    ax3.set_title("masked output")
    ax4= fig.add_subplot(236)
    ax4.imshow(image_nor,  cmap='gray', vmin=0, vmax=255)
    ax4.set_title("normalized_image")
    plt.show()
    
    testinglst = ['eye_left.jpg','eye_right.jpg']
    for i in testinglst:
        print(i)
        image_size=224
        path=i
        img = image.load_img(path, target_size=(image_size, image_size))
        x = image.img_to_array(img)
        img_4d=x.reshape(1,224,224,3)
        model = loaded_model
        predictions = model.predict(img_4d)
        print(predictions[0])
        new_pred=np.argmax(predictions[0])
        print(new_pred)
    
        dict1={0:'Roshan',
                1:'Yash'}
    
        a=dict1[new_pred]
    
        print(str(a))
        print("-----------------------------------------------")
    
    image = roi_color1
    # image = cv2.imread('face.jpg')
    # detect color percentage
    eye_color(roi_color1)
    cv2.imwrite('result.jpg', image)    
    cv2.waitKey(0)

# Release the camera capture object
video_capture.release()
