import cv2
import numpy as np
from mtcnn.mtcnn import MTCNN
import tensorflow
from tensorflow.keras.preprocessing import image

from matplotlib import pyplot as plt

detector = MTCNN()

json_file = open('allmodel/res_model.json', 'r')
loaded_model_json = json_file.read()
loaded_model = tensorflow.keras.models.model_from_json(loaded_model_json)
loaded_model.load_weights("allmodel/res_model.h5")

segmentmodel = tensorflow.keras.models.load_model('allmodel/Iria_90.h5', compile=False)
print("Loaded model from disk")

# ----------------------------------------------------------------------------------------------------------------
# define HSV color ranges for eyes colors
class_name = ("Gray", "Blue Gray", "Brown", "Brown Gray", "Brown Black", "Green", "Blue Gray", "Other")
# class_name = ("Blue", "Blue Gray", "Brown", "Brown Gray", "Brown Black", "Green", "Green Gray", "Other")
EyeColor = {
    class_name[0] : ((166, 21, 50), (240, 100, 85)),
    class_name[1] : ((166, 2, 25), (300, 20, 75)),
    class_name[2] : ((2, 20, 20), (40, 100, 60)),
    class_name[3] : ((20, 3, 30), (65, 60, 60)),
    class_name[4] : ((0, 10, 5), (40, 40, 25)),
    class_name[5] : ((60, 21, 50), (165, 100, 85)),
    class_name[6] : ((60, 2, 25), (165, 20, 65))
}

def check_color(hsv, color):
    if (hsv[0] >= color[0][0]) and (hsv[0] <= color[1][0]) and (hsv[1] >= color[0][1]) and \
    hsv[1] <= color[1][1] and (hsv[2] >= color[0][2]) and (hsv[2] <= color[1][2]):
        return True
    else:
        return False

# define eye color category rules in HSV space
def find_class(hsv):
    color_id = 7
    for i in range(len(class_name)-1):
        if check_color(hsv, EyeColor[class_name[i]]) == True:
            color_id = i

    return color_id

def eye_color(image):
    imgHSV = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    h, w = image.shape[0:2]
    imgMask = np.zeros((image.shape[0], image.shape[1], 1))
    
    result = detector.detect_faces(image)
    print(result)
    if result == []:
        print('Warning: Can not detect any face in the input image!')
        return

    bounding_box = result[0]['box']
    left_eye = result[0]['keypoints']['left_eye']
    right_eye = result[0]['keypoints']['right_eye']

    eye_distance = np.linalg.norm(np.array(left_eye)-np.array(right_eye))
    eye_radius = eye_distance/15 # approximate
   
    cv2.circle(imgMask, left_eye, int(eye_radius), (255,255,255), -1)
    cv2.circle(imgMask, right_eye, int(eye_radius), (255,255,255), -1)

    cv2.rectangle(image,
              (bounding_box[0], bounding_box[1]),
              (bounding_box[0]+bounding_box[2], bounding_box[1] + bounding_box[3]),
              (255,155,255),
              2)

    cv2.circle(image, left_eye, int(eye_radius), (0, 155, 255), 1)
    cv2.circle(image, right_eye, int(eye_radius), (0, 155, 255), 1)

    eye_class = np.zeros(len(class_name), np.float)

    for y in range(0, h):
        for x in range(0, w):
            if imgMask[y, x] != 0:
                eye_class[find_class(imgHSV[y,x])] +=1 

    main_color_index = np.argmax(eye_class[:len(eye_class)-1])

    print("\n\nDominant Eye Color: ", class_name[main_color_index])
    
    label = '%s' % class_name[main_color_index]  
    cv2.putText(image, label, (left_eye[0]-10, left_eye[1]-40), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (155,255,0))
    # Create a named window with a specific size
    cv2.namedWindow('EYE-COLOR-DETECTION', cv2.WINDOW_NORMAL)  # Use WINDOW_NORMAL for resizable window
    
    # Resize the window to your desired dimensions (e.g., 800x600)
    cv2.resizeWindow('EYE-COLOR-DETECTION', 800, 600)
    
    # Display the image in the resized window
    cv2.imshow('EYE-COLOR-DETECTION', image)
    
    # Wait for a key press and then close the window
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def displaypopup(prediction_image):        
    # desired_size = (256, 256)
    # prediction_image1 = cv2.resize(prediction_image, desired_size)
    # screen_width = 2000  # Change this to your screen's width
    # screen_height = 1000  # Change this to your screen's height
    # x_position = (screen_width - desired_size[0]) // 2
    # y_position = (screen_height - desired_size[1]) // 2
    cv2.namedWindow('Segmented Mask', cv2.WINDOW_NORMAL)
    cv2.moveWindow('Segmented Mask', 500, 500)
    cv2.imshow('Segmented Mask', prediction_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# ---------------------------------------------------------------   -------------------------------------------------

best_frame = cv2.imread('testimages/r4.jpg')
if best_frame is not None:
      
    gray = cv2.cvtColor(best_frame, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    eye_cascade = cv2.CascadeClassifier('haarcascade_eye_tree_eyeglasses.xml')
    
    faces = face_cascade.detectMultiScale(gray, 1.3, 4)
    
    for i, (x, y, w, h) in enumerate(faces):
        roi_color = best_frame[y:y+h, x:x+w]
        eyes = eye_cascade.detectMultiScale(roi_color)
        
        eye_color(roi_color)
        cv2.waitKey(0)  # Wait for a key press indefinitely
        cv2.destroyAllWindows()  # Close all OpenCV windows

        cv2.imwrite('result.jpg', best_frame)  
        
        for j, (ex, ey, ew, eh) in enumerate(eyes):
            eye_crop = roi_color[ey:ey+eh, ex:ex+ew]
            resized_eye = cv2.resize(eye_crop, (128, 128))
            
            if j == 0:
                eye_filename = 'eye_left.jpg'
                cv2.imwrite('eye_left1.jpg', resized_eye)
                cv2.imwrite(eye_filename, resized_eye)
            else:
                eye_filename = 'eye_right.jpg'
                cv2.imwrite(eye_filename, resized_eye)
        
    testinglst = ['eye_left.jpg','eye_right.jpg']
    for i in testinglst:
        print(i)
        image_size=224
        path=i
        img = image.load_img(path, target_size=(image_size, image_size))
        x = image.img_to_array(img)
        img_4d=x.reshape(1,224,224,3)
        model = loaded_model
        predictions = model.predict(img_4d)
        print(predictions[0])
        new_pred=np.argmax(predictions[0])
        print(new_pred)
    
        dict1={0:'Yash',
                1:'Roshan'}
    
        a=dict1[new_pred]
    
        print(str(a))
        print("-----------------------------------------------")
                
    SIZE_X = 128
    SIZE_Y = 128
    OGX = 3000
    OGY = 1700
    
    imageofgr = cv2.imread('eye_left1.jpg', cv2.IMREAD_GRAYSCALE)
    cv2.imwrite('eye_left1.jpg', imageofgr)
    
    test_img = cv2.imread('eye_left1.jpg', cv2.IMREAD_COLOR)
    test_img = cv2.cvtColor(test_img, cv2.COLOR_RGB2BGR)
    test_image = test_img
    test_img = cv2.resize(test_img, (SIZE_Y, SIZE_X))    
    
    test_img = np.expand_dims(test_img, axis=0)
    
    prediction = segmentmodel.predict(test_img)
    
    test_image = cv2.resize(test_image, (OGX, OGY))
    prediction_image = prediction.reshape((SIZE_X,SIZE_Y))
    
    prediction_image = cv2.resize(prediction_image, (OGX, OGY))
    plt.imsave('segmented.jpg', prediction_image, cmap='gray')
    displaypopup(prediction_image)
    
    imgg = cv2.imread('segmented.jpg')
    
    #imgg2 = cv2.resize(imgg2, (SIZE_Y, SIZE_X))
    imgg = cv2.resize(imgg, (OGX, OGY))
    imgg =  cv2.cvtColor(imgg, cv2.COLOR_RGB2BGR)
    annd = cv2.bitwise_and(imgg, test_image)
    
    plt.imsave('segmentedfinal.jpg', annd, cmap='gray')
    displaypopup(annd)
    
    # Wait for a key event and close the window when a key is pressed
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
